# Harder Contracting Work Order Board — Setup Guide

## Your live app

**https://certifiedjoes-art.github.io/Work-orders/**

This is the link to share with all your mechanics. It's fully set up —
Firebase is connected, so everyone who opens this link sees the same
shared board in real time.

## Add it to your home screen (do this on each phone)

**iPhone (Safari):**
1. Open the link above in Safari
2. Tap the **Share icon** (square with an arrow pointing up)
3. Scroll down, tap **"Add to Home Screen"**
4. Tap **Add**

**Android (Chrome):**
1. Open the link in Chrome
2. Tap the **⋮ menu** (top right)
3. Tap **"Add to Home screen"** or **"Install app"**

**Windows/Mac/Linux (Chrome or Edge):**
1. Open the link
2. Click the install icon in the address bar, or the **⋮** menu → **"Install"**

Once added, it opens full-screen with the orange "H" icon like a normal app.

## Sharing with your employees

Just text, email, or AirDrop them this link:
**https://certifiedjoes-art.github.io/Work-orders/**

They open it and do the same "Add to Home Screen" step above. Everyone
sees the same board update live.

## Making changes to the app later

You do **not** need to redo the Firebase setup again — that's done for
good. Your data lives in Firebase, separate from the app files.

When you want a change (new feature, different colors, new field, etc.):

1. Ask me (Claude) to make the change
2. I'll hand you an updated `index.html` file (and occasionally an updated
   `manifest.json` or `sw.js`, if needed — I'll tell you which changed)
3. Go to **github.com**, log in, open your **Work-orders** repository
4. Tap **"Add file" → "Upload files"** (same as before)
5. Select the new file(s) — GitHub will ask if you want to replace the
   existing one, confirm yes
6. Scroll down, tap **"Commit changes"**
7. Wait about a minute — your link stays exactly the same, nothing to
   re-share with your team

## Your accounts

- **GitHub repository:** certifiedjoes-art / Work-orders
- **Firebase project:** harder-contracting (Realtime Database, free tier)

You generally won't need to touch Firebase again unless you want to add
things like a login/password step later — just ask if you ever want that.

### A note on security

Your database currently allows anyone with your app's link to read and
write data (no login required) — this matches how the app works today,
where mechanics just pick their name from a list. Fine for an internal
tool, but be mindful about who you share the link with. If you ever want
it locked down further, let me know and we can add that.

## PIN codes & Face ID / Touch ID

Each mechanic sets a 4-digit PIN the first time they tap their name (existing
mechanics will be asked to set one the next time they sign in too). This
keeps people from accidentally tapping into a coworker's name on the shared
tablet.

On a mechanic's own phone, after entering their PIN once, they'll be offered
the option to use Face ID / Touch ID instead next time — this is a
per-device shortcut only, not shared across phones. It can be turned on or
off anytime from "Enable/Turn off Face ID" on the board.

**Forgot a PIN?** Tap their name, then "Forgot PIN? Reset it" — this clears
their PIN and lets them set a new one immediately. There's no email/password
recovery since the app doesn't use accounts.

**Honest security note:** this is a convenience/deterrence feature, not
full-strength security — the database itself doesn't require login to reach
directly. It's meant to prevent mix-ups on a shared device, not to defend
against someone determined to get in another way.

## Team management (admin only)

Joe is set up as the first admin. Admins see a "⚙️ Team" button on the
dashboard where they can:
- Promote/demote other admins
- Remove someone from the team (e.g. when employment ends) — this removes
  their name and PIN so they can no longer sign in, but keeps all their
  past work orders on record for history

You can't remove or demote yourself from the Team screen (to avoid
accidentally locking yourself out) — ask another admin if you ever need
that changed.

## Editable checklists

All checklists — including the built-in machine ones (Buncher, Excavator,
Crawler, Processor, Skidder) — can now be edited from the Checklists page.
Tap "Edit" on any checklist to change its name or steps.

## Offline support

The app now works with no signal at all:
- The app itself (not just your data) loads even with zero connection,
  once it's been opened at least once with a connection first
- Your existing work orders, machines, and checklists are still visible
  offline (from the last time the app synced)
- Changes you make offline are queued by Firebase and sync automatically
  once you're back in range — **as long as you don't fully close the app
  before reconnecting**. If you do force-close it while offline, that one
  unsaved change may need to be re-entered once you're back online.

**Important for future updates**: this update added a file called `sw.js`
that helps the app work offline. From now on, whenever I hand you an
updated `index.html`, I'll also bump a version number inside `sw.js` —
**always upload both files together** when I mention `sw.js` changed, or
phones can get stuck on an old cached version again.

## Timesheets

Every mechanic gets a "⏱️ Time Clock" button on the dashboard to:
- Clock in / clock out for the day
- Start/end a lunch break
- Log which units or jobs they worked on with hours (free text — works for
  unit numbers, "Labour," "Shop cleanup," anything)

**Mechanics can only see their own timesheet, and can't edit it
themselves** — there's no way for them to view anyone else's hours, and
if they forget to clock in/out or make a mistake, they just need to ask
an admin to fix it. Their own history shows "Ask admin to fix a mistake"
instead of an Edit button.

**Admins** (just Joe right now) get a separate "📊 Timesheets" screen to:
- View everyone's shifts, filterable by person and date range
- Edit or delete anyone's shift — this is the only way clock in/out
  mistakes get fixed, at the mechanic's request
- See total hours per person
- Tap "Export & Share" to generate a CSV and open the share sheet
  (choose Mail, and it'll come through as an attachment ready to send)

There's also an email address field and an "automatic weekly email"
toggle in that screen — the toggle is there and ready, but actually
sending automatically needs one more setup step (a small backend + email
service) whenever you're ready to take that on.

**One rule mechanics need to know**: the app won't let them clock out for
the day without either logging a lunch break or confirming they worked
through it — a popup handles this automatically.

## Timesheet upgrades

- **"Break" instead of "Lunch"** — the button now says Start/End Break,
  since it doesn't have to specifically be lunch. Still unpaid time,
  same as before.
- **Who's clocked in right now** — admins see a live list at the top of
  the Timesheets screen.
- **Weekly view with overtime flag** — admins can page week by week
  (Sunday-Saturday) and see a ⚠️ next to anyone over 40 hours that week.
- **Weekly approval** — tap "Approve this week" to lock it, mainly so
  you have a record of what's been reviewed. Since only admins can edit
  shifts at all now, this doesn't change who can touch what — it's just
  a marker of "this week is finalized." Un-approve anytime if you need
  to reopen it.
- **"How much have I worked?"** — mechanics can pick any two dates on
  their own Time Clock screen and see total hours in that range.

## Look and feel

- Joke of the day banner at the top of the dashboard (clean jokes only,
  same one for everyone, changes daily) — dismissible with the ✕
- Subtle background gradient and a faint tree silhouette on the login
  screen for a bit more polish, echoing your logo

## Milestones

Each mechanic's completed work orders are tracked automatically:
- **5 and 10 completed** — auto-posts a shoutout to the team feed, no
  action needed
- **50, 100, and every 50 after that** — instead of auto-posting, you
  (as admin) get a popup asking to add a personal note. Skip it and a
  solid default message still gets posted, so nobody's big milestone
  goes unrecognized even on a busy day

## Real authentication — Phase 1 (this update)

This update quietly creates a real, secure login for each mechanic the
next time they enter their PIN — but **your database security rules
have NOT changed yet**. Your app is exactly as protected (or open) as
it was before this update. That's intentional — we're rolling this out
in two safe steps.

**What changed for everyone:**
- **PINs are now 6 digits**, not 4 (Firebase's minimum). Everyone —
  including existing mechanics — will be asked to set a new one the
  next time they tap their name.
- Setting that new PIN quietly creates their real, secure Firebase
  account behind the scenes. Nothing to do differently — same tap name
  → enter PIN flow as always.

**What to do now:**
1. Upload this update (`index.html` + `sw.js` together, as always)
2. Have every mechanic tap their name and set their new 6-digit PIN at
   least once — this is what creates their real account
3. Once **everyone** has done this, come back and tell me — that's
   when we'll do Phase 2: actually locking the security rules down

**Do NOT change your Firebase security rules until everyone has
migrated.** If you (or anyone) changes them early, before everyone has
a real account, you risk locking people out.

**What "Forgot PIN" now means:** since accounts are real, mechanics can
no longer reset their own forgotten PIN by themselves. If someone
forgets theirs:
1. Go to **Firebase Console → Authentication → Users**
2. Find their email (it'll look like `firstname@harder-contracting.app`
   — this is a made-up address, not a real inbox, just how Firebase
   tells people apart)
3. Delete that user
4. In the app, go to **Team → Reset login** next to their name
5. They can now tap their name again and set a brand new PIN

Biometric (Face ID / Touch ID) still works the same way as before —
it's just now backed by a real login instead of a simple local check.

## Multiple recipients + monthly summary

The Timesheets screen now has three separate report settings, each with
its own recipient list:

- **Weekly timesheet** — the CSV of every shift, sent every Monday. Add
  as many emails as you want, separated by commas.
- **Weekly backup** — the full app backup file, sent every Monday,
  separately from the timesheet email. Usually just your own email.
- **Monthly hours summary** — a simple total-hours-per-person report,
  sent the 1st of every month. One email (e.g. your bookkeeper).

The "Weekly emails turned on" toggle only affects the weekly timesheet
and backup — the monthly summary always sends if an email is set there.

### One more Cloud Scheduler job needed

The monthly summary needs its own scheduled trigger, separate from the
weekly one:

1. Go to **Cloud Scheduler** in Google Cloud Console
2. Click **"Create Job"**
3. Name: `monthly-timesheet-summary`
4. Frequency: `0 6 1 * *` (6:00 AM on the 1st of every month)
5. Timezone: same as your weekly job
6. Target type: HTTP
7. URL: your same function URL, but add `&mode=monthly` to the end —
   e.g. `https://weekly-backup-and-email-....run.app?key=YOUR_SECRET&mode=monthly`
8. HTTP method: GET
9. Create

Your existing weekly job doesn't need any changes — it already defaults
to weekly behavior when no `mode` is specified.

## Time clock

Clock in/out now works freely, any time, no restrictions. The break
(lunch) buttons work the same as before, just without the "must log a
break before clocking out" requirement — that can be brought back later
once the break buttons have been in real use for a while.
